/*
 *  base64.h
 *  SSCrypto
 *
 *  Created by Ed Silva on 10/3/04.
 *  Copyright 2004 Septicus Software. All rights reserved.
 *
 */

size_t Curl_base64_decode(const char *src, char *dest);
size_t Curl_base64_encode(const char *inp, size_t insize, char **outptr);
